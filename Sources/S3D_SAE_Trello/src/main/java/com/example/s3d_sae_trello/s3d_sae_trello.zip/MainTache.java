package com.example.s3d_sae_trello;

public class MainTache {
    public static void main(String[] args) {
        /**
        // Création d'une tâche classique
        Tache tachePrincipale = new Tache(11, "Tache classique", "Alice", "Dupont", 1, 120, "description_tache");

        // Création de sous-tâches
        SousTache sousTache1 = new SousTache(12,"Sous Tache 1", "Bob", "Martin", 1, 60, "description_tache");
        sousTache1.ajouterDescription("Faire le resume du cours");

        SousTache sousTache2 = new SousTache(13, "Sous Tache 2", "Charlie", "Brown", 1, 450, "description_tache");
        sousTache2.ajouterDescription("Recherche documentaire");


        // Création d'une tâche complexe pouvant avoir des sous-tâches
        SousTache tacheComplexe = new SousTache(14, "Tache Complexe", "David", "Smith", 2, 900, "description_tache");
        tacheComplexe.ajouterDescription("Commencer le memoire");


        // Ajout des sous-tâches à la tâche complexe
        tacheComplexe.ajouterSousTache(sousTache1);
        tacheComplexe.ajouterSousTache(sousTache2);


        // Gestion des dépendances
        tacheComplexe.ajouterDependanceMere(tachePrincipale); // Ajout de tachePrincipale comme tâche mère
        tacheComplexe.ajouterDependanceFille(sousTache1); // Ajout de sousTache1 comme tache

        // Affichage de la tâche complexe avec ses sous-tâches
        System.out.println(tacheComplexe);
         */
    }
}